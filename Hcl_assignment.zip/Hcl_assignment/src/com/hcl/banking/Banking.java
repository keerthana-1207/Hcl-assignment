package com.hcl.banking;

public class Banking {
	
	private int transaction1;
	private int transaction2;
	private int transaction3;
	private int transaction4;
	private int transaction5;
	private int totalbalance;
	public Banking() {
		super();
	}
	public Banking( int transaction1,int transaction2,int transaction3,int transaction4,int transaction5,int totalbalance) {
		super();
		this.transaction1 = transaction1;
		this.transaction2 = transaction2;
		this.transaction3 = transaction3;
		this.transaction4 = transaction4;
		this.transaction5 = transaction5;
		this.totalbalance = totalbalance;
	}
	public int getTransaction1() {
		return transaction1;
	}
	public void setTransaction1(int transaction1) {
		this.transaction1 = transaction1;
	}
	public int getTransaction2() {
		return transaction2;
	}
	public void setTransaction2(int transaction2) {
		this.transaction2 = transaction2;
	}
	public int getTransaction3() {
		return transaction3;
	}
	public void setTransaction3(int transaction3) {
		this.transaction3 = transaction3;
	}
	public int getTransaction4() {
		return transaction4;
	}
	public void setTransaction4(int transaction4) {
		this.transaction4 = transaction4;
	}
	public int getTransaction5() {
		return transaction5;
	}
	public void setTransaction5(int transaction5) {
		this.transaction5 = transaction5;
	}
	public int getTotalbalance() {
		return totalbalance;
	}
	public void setTotalbalance(int totalbalance) {
		this.totalbalance = totalbalance;
	}
	@Override
	public String toString() {
		return String.format(
				"Product [transaction1=%s, transaction2=%s, transaction3=%s, transaction4=%s, transaction5=%s, totalbalance=%s]",
				transaction1, transaction2, transaction3, transaction4, transaction5, totalbalance);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + totalbalance;
		result = prime * result + transaction1;
		result = prime * result + transaction2;
		result = prime * result + transaction3;
		result = prime * result + transaction4;
		result = prime * result + transaction5;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Banking other = (Banking) obj;
		if (totalbalance != other.totalbalance)
			return false;
		if (transaction1 != other.transaction1)
			return false;
		if (transaction2 != other.transaction2)
			return false;
		if (transaction3 != other.transaction3)
			return false;
		if (transaction4 != other.transaction4)
			return false;
		if (transaction5 != other.transaction5)
			return false;
		return true;
	}
	
}

	