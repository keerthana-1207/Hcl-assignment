package com.hcl.client;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.hcl.banking.Banking;
import com.hcl.dbcon.MyConnection;

public class Client {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws SQLException  {
		
		Connection con = MyConnection.getDBconnection();
		
		
		 
        while (true) {
        	System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            System.out.println("\n|| Transactiondetails || ");
            System.out.println("\n1. Display all transaction");
            System.out.println("2.Transfer Amount ");
            System.out.println("3. Updated Account balance");
            System.out.print("\nPlease enter your choice (1-3) : ");
            int choice = sc.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Display all transaction ");
                displayTransaction(con);
                break;
            case 2:
                System.out.println("Transfer Amount  ");
                transferAmount(con);
                break;
            case 3:
                System.out.println("Updated Account balance  ");
                updatedAmount(con);
                break;
            
            case 4:
                System.out.println("Thanks for using my program");
                System.exit(0);
            default:
                System.out.println("Incorrect Option . Please select (1-3)");
            }
        }
    }
	
		
	
		
	private static void displayTransaction(Connection con) throws SQLException {
		System.out.println("Displaying all the  Products : ");
		Statement stat = con.createStatement();
		ResultSet res = stat.executeQuery("select * from accountdetails");
		ResultSetMetaData rsmd = res.getMetaData();
		int count = rsmd.getColumnCount();
		while(res.next()) {
			System.out.println("\n");	
			for(int i =1;i<=count;i++)
			{
				System.out.print(rsmd.getColumnName(i)+ " = ");
				System.out.print(res.getInt(i)+ "\n ");
			}
				
			

		}
	}
	
	
	
	private static void transferAmount(Connection con) throws SQLException {
		System.out.println("Please Entert the Amount to transfer");
		System.out.print("\nEnter Amount : ");int Amount = sc.nextInt();
		System.out.println("\n your Amount" + Amount + " rs has been transfered");
		
	}
	
	
	
	
     private static void updatedAmount(Connection con) throws SQLException {
		
		Statement stat = con.createStatement();
		ResultSet res = stat.executeQuery("select * from accountdetails");
		if (res.next())
		{
			
		int a= res.getInt(6);
		int b= 1000;
		int c= a-b;

		System.out.println(c);
		}
		
	}
	
}
		
		
		
		
		
		
		
		




