package com.hcl.dbcon;
import java.sql.*;
public class MyConnection{
	public static Connection getDBconnection() throws SQLException {

		
		
		String dbUrl = "jdbc:mysql://localhost:3306/banktransaction";
		String user = "root";		
		String pass = "keerthana";
		Connection con = DriverManager.getConnection(dbUrl, user, pass);
		return con;
		

	}

}
